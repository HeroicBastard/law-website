import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Scale,
  Car,
  Building2,
  Phone,
  Mail,
  MapPin,
  ArrowRight,
  Truck,
  Brain,
  Pill,
  Factory,
  AlertTriangle,
  Award,
  Shield,
  Users,
  ThumbsUp,
  CheckCircle,
} from "lucide-react"
import { AnimatedHero } from "@/components/ui/animated-hero"
import { TestimonialSection } from "@/components/testimonial-section"
import { TrustIndicators } from "@/components/trust-indicators"
import { UrgencyBanner } from "@/components/urgency-banner"
import { AnnouncementBar } from "@/components/announcement-bar"
import { EnhancedHeader } from "@/components/enhanced-header"

export default function LandingPage() {
  return (
    <>
      <AnnouncementBar />
      <EnhancedHeader />
      <main>
        <section id="home">
          <AnimatedHero />
        </section>
        
        <TrustIndicators />
        
        <UrgencyBanner />

        <section id="why-choose-us" className="py-16 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Choose MeshLaw?</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                When you're injured, you need more than just a lawyer. You need a dedicated advocate who will fight tirelessly for your rights and maximum compensation.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-amber-50 p-6 rounded-lg border border-amber-100 text-center">
                <div className="bg-amber-100 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Award-Winning</h3>
                <p className="text-gray-700">
                  Recognized as one of the top personal injury law firms in the country with numerous industry awards.
                </p>
              </div>
              
              <div className="bg-amber-50 p-6 rounded-lg border border-amber-100 text-center">
                <div className="bg-amber-100 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">No Fee Unless We Win</h3>
                <p className="text-gray-700">
                  We work on a contingency basis - you pay nothing unless we recover compensation for you.
                </p>
              </div>
              
              <div className="bg-amber-50 p-6 rounded-lg border border-amber-100 text-center">
                <div className="bg-amber-100 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Personalized Attention</h3>
                <p className="text-gray-700">
                  You'll work directly with experienced attorneys who are committed to your case, not paralegals.
                </p>
              </div>
              
              <div className="bg-amber-50 p-6 rounded-lg border border-amber-100 text-center">
                <div className="bg-amber-100 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ThumbsUp className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Proven Results</h3>
                <p className="text-gray-700">
                  Our track record speaks for itself with over $500 million recovered for our clients.
                </p>
              </div>
            </div>
            
            <div className="mt-12 text-center">
              <Button size="lg" className="bg-amber-600 hover:bg-amber-500 font-bold">
                Schedule Your Free Consultation Today
              </Button>
            </div>
          </div>
        </section>

        <section id="case-results" className="py-16 bg-gray-50">
          <div className="container">
            <div className="text-center mb-12">
              <span className="text-amber-600 font-bold text-sm uppercase tracking-wider">Success Stories</span>
              <h2 className="text-3xl font-bold mb-4">Our Case Results</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                We fight to maximize compensation for our clients. These are just a few examples of how we've turned
                lawful claims into substantial settlements.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">Auto Accident</h3>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Initial Offer</p>
                      <p className="text-lg font-semibold">$15,000</p>
                    </div>
                    <ArrowRight className="h-5 w-5 text-amber-600" />
                    <div>
                      <p className="text-sm text-gray-500">Settlement</p>
                      <p className="text-lg font-semibold text-amber-600">$145,000</p>
                    </div>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-md mb-4">
                    <p className="text-amber-800 font-semibold">866% Increase</p>
                  </div>
                  <p className="text-gray-600">
                    Client was initially offered a minimal settlement by the insurance company. After our intervention,
                    we secured a settlement nearly 9 times the original offer.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">Medical Malpractice</h3>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Initial Offer</p>
                      <p className="text-lg font-semibold">Denied</p>
                    </div>
                    <ArrowRight className="h-5 w-5 text-amber-600" />
                    <div>
                      <p className="text-sm text-gray-500">Settlement</p>
                      <p className="text-lg font-semibold text-amber-600">$3.5 Million</p>
                    </div>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-md mb-4">
                    <p className="text-amber-800 font-semibold">Substantial Recovery</p>
                  </div>
                  <p className="text-gray-600">
                    After a hospital denied responsibility for a surgical error, we built a compelling case that
                    resulted in a multi-million dollar settlement for our client.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2">Slip and Fall</h3>
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-sm text-gray-500">Initial Offer</p>
                      <p className="text-lg font-semibold">$25,000</p>
                    </div>
                    <ArrowRight className="h-5 w-5 text-amber-600" />
                    <div>
                      <p className="text-sm text-gray-500">Settlement</p>
                      <p className="text-lg font-semibold text-amber-600">$215,000</p>
                    </div>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-md mb-4">
                    <p className="text-amber-800 font-semibold">760% Increase</p>
                  </div>
                  <p className="text-gray-600">
                    Our client slipped on an unmarked wet floor in a retail store. We proved negligence and secured a
                    settlement that covered all medical expenses and lost wages.
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="mt-10 text-center">
              <Button className="bg-amber-600 hover:bg-amber-500">
                View More Case Results <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>
        
        <section id="testimonials">
          <TestimonialSection />
        </section>

        <section id="practice-areas" className="py-16 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <span className="text-amber-600 font-bold text-sm uppercase tracking-wider">Areas of Expertise</span>
              <h2 className="text-3xl font-bold mb-4">Our Practice Areas</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                At MeshLaw, we specialize in representing clients in various personal injury matters, fighting
                tirelessly to get the compensation they deserve.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Car className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Car Accidents</h3>
                  <p className="text-gray-600 mb-4">
                    Representation for victims of motor vehicle accidents, helping you navigate insurance claims and
                    secure fair compensation.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Building2 className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Slip and Fall Injuries</h3>
                  <p className="text-gray-600 mb-4">
                    Legal support for those injured in hazardous premises, holding property owners accountable for
                    negligence.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Scale className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Wrongful Death</h3>
                  <p className="text-gray-600 mb-4">
                    Compassionate assistance for families seeking justice for a loved one's untimely death due to
                    negligence.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Truck className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Truck Accidents</h3>
                  <p className="text-gray-600 mb-4">
                    Specialized representation for victims of commercial trucking accidents, dealing with complex
                    liability issues.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Car className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Rideshare Accidents</h3>
                  <p className="text-gray-600 mb-4">
                    Expert representation for victims of Uber/Lyft-related accidents, navigating the unique insurance
                    challenges.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Brain className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Traumatic Brain Injuries</h3>
                  <p className="text-gray-600 mb-4">
                    Specialized legal support for clients suffering severe head trauma, focusing on long-term care and
                    compensation.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="mass-torts" className="py-16 bg-gray-50">
          <div className="container">
            <div className="text-center mb-12">
              <span className="text-amber-600 font-bold text-sm uppercase tracking-wider">Complex Litigation</span>
              <h2 className="text-3xl font-bold mb-4">Mass Torts</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Our firm has extensive experience handling complex mass tort litigation, representing clients who've
                been harmed by dangerous drugs, defective medical devices, and toxic exposure.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <AlertTriangle className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Defective Medical Devices</h3>
                  <p className="text-gray-600 mb-4">
                    Representation for victims of defective implants, prosthetics, and other medical devices that have
                    caused harm.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Pill className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Dangerous Pharmaceuticals</h3>
                  <p className="text-gray-600 mb-4">
                    Support for individuals harmed by unsafe prescription drugs, holding pharmaceutical companies
                    accountable.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="mb-4 bg-amber-100 p-3 rounded-full w-fit">
                    <Factory className="h-6 w-6 text-amber-600" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Environmental Contamination</h3>
                  <p className="text-gray-600 mb-4">
                    Legal representation for victims of toxic exposure in water, air, and land contamination cases.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="news" className="py-16 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <span className="text-amber-600 font-bold text-sm uppercase tracking-wider">Stay Informed</span>
              <h2 className="text-3xl font-bold mb-4">Latest News</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Stay updated with the latest legal news, case victories, and insights from our team.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <p className="text-sm text-amber-600 mb-2">March 1, 2025</p>
                  <h3 className="text-xl font-bold mb-3">Record Settlement in Truck Accident Case</h3>
                  <p className="text-gray-600 mb-4">
                    MeshLaw secures a record-breaking settlement for a client severely injured in a commercial trucking
                    accident.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Read More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <p className="text-sm text-amber-600 mb-2">February 15, 2025</p>
                  <h3 className="text-xl font-bold mb-3">New Partner Joins MeshLaw Litigation Team</h3>
                  <p className="text-gray-600 mb-4">
                    Renowned trial attorney Sarah Johnson joins MeshLaw, bringing 15 years of experience in complex
                    personal injury litigation.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Read More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <p className="text-sm text-amber-600 mb-2">January 19, 2025</p>
                  <h3 className="text-xl font-bold mb-3">MeshLaw Named Top Personal Injury Firm</h3>
                  <p className="text-gray-600 mb-4">
                    MeshLaw has been recognized as one of the top personal injury law firms in the region for the fifth
                    consecutive year.
                  </p>
                  <Link href="#" className="text-amber-600 font-medium flex items-center hover:underline">
                    Read More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="contact" className="py-16 bg-amber-50">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <span className="text-amber-600 font-bold text-sm uppercase tracking-wider">Contact Us</span>
                <h2 className="text-3xl font-bold mb-6">Get a Free Consultation</h2>
                <p className="text-gray-600 mb-8">
                  Don't wait another day to get the compensation you deserve. Our experienced attorneys are ready to fight for your rights and help you rebuild your life.
                </p>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <Phone className="h-6 w-6 text-amber-600 mt-1" />
                    <div>
                      <h3 className="font-bold text-lg">Phone</h3>
                      <p className="text-gray-600">(310) 795-1000</p>
                      <p className="text-gray-500 text-sm">Available 24/7 for emergencies</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Mail className="h-6 w-6 text-amber-600 mt-1" />
                    <div>
                      <h3 className="font-bold text-lg">Email</h3>
                      <p className="text-gray-600">contact@meshlaw.com</p>
                      <p className="text-gray-500 text-sm">We'll respond within 24 hours</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <MapPin className="h-6 w-6 text-amber-600 mt-1" />
                    <div>
                      <h3 className="font-bold text-lg">Office</h3>
                      <p className="text-gray-600">1234 Los Angeles, Suite 100</p>
                      <p className="text-gray-600">Anycity, ST 12345</p>
                      <p className="text-gray-500 text-sm">Monday-Friday: 9am-5pm</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 p-6 bg-white rounded-lg shadow-md border border-amber-100">
                  <h3 className="font-bold text-lg mb-4">Client Guarantee</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">Free initial consultation with an experienced attorney</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">No fees unless we win your case</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">Regular updates on your case progress</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">Direct access to your attorney throughout your case</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-lg border border-amber-100">
                <h3 className="text-xl font-bold mb-6">Start Your Free Case Review</h3>
                <form className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <input id="name" className="w-full px-3 py-2 border rounded-md" placeholder="John Doe" />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="w-full px-3 py-2 border rounded-md"
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">
                      Phone
                    </label>
                    <input
                      id="phone"
                      type="tel"
                      className="w-full px-3 py-2 border rounded-md"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Tell us about your case
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full px-3 py-2 border rounded-md"
                      placeholder="Please provide a brief description of your case..."
                    ></textarea>
                  </div>
                  <Button className="w-full bg-amber-600 hover:bg-amber-500 text-lg py-6 font-bold">Submit Your Case for Review</Button>
                  <div className="flex items-center justify-center gap-2">
                    <div className="flex">
                      <svg className="h-4 w-4 text-amber-500 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2
</main>
      <FloatingContact />
    </>
  )
}\

