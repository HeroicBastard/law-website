"use client"

import { useState } from "react"
import { AlertCircle, X, Clock } from "lucide-react"

export function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  return (
    <div className="bg-amber-600 text-white py-2 relative">
      <div className="container flex items-center justify-center">
        <div className="flex items-center gap-2 text-sm font-medium">
          <AlertCircle className="h-4 w-4" />
          <span className="hidden sm:inline">Time-sensitive:</span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" /> Limited time to file your claim. Call now for a free case review!
          </span>
          <a href="tel:3107951000" className="underline font-bold ml-1 whitespace-nowrap hover:text-amber-200">
            (310) 795-1000
          </a>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="absolute right-4 text-white hover:text-amber-200"
          aria-label="Close announcement"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}

