"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Scale, Phone, Menu, X, ChevronRight, Award, Clock, MessageSquare, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function EnhancedHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full bg-white transition-all duration-300",
        scrolled ? "shadow-md py-2" : "shadow-sm py-4",
      )}
    >
      <div className="container">
        {/* Top bar with contact info */}
        <div className="hidden lg:flex items-center justify-between border-b border-gray-100 pb-2 mb-2">
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-gray-600">
              <Phone className="h-4 w-4 text-amber-600" />
              <span>Available 24/7:</span>
              <a href="tel:3107951000" className="font-bold text-amber-600 hover:underline">
                (310) 795-1000
              </a>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <MessageSquare className="h-4 w-4 text-amber-600" />
              <span>Email:</span>
              <a href="mailto:contact@meshlaw.com" className="hover:underline">
                contact@meshlaw.com
              </a>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Award className="h-4 w-4 text-amber-600" />
              <span className="text-xs font-medium">Top Rated Personal Injury Firm</span>
            </div>
            <div className="h-4 w-px bg-gray-300"></div>
            <a href="#" className="text-xs font-medium hover:text-amber-600">
              Client Portal
            </a>
            <div className="h-4 w-px bg-gray-300"></div>
            <a href="#" className="text-xs font-medium hover:text-amber-600">
              Careers
            </a>
          </div>
        </div>

        {/* Main header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scale className="h-7 w-7 text-amber-600" />
            <div className="flex flex-col">
              <span className="text-xl font-bold">MeshLaw</span>
              <span className="text-xs text-gray-500 -mt-1">Los Angeles Personal Injury Attorneys</span>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-6">
            <Link href="#home" className="text-sm font-medium hover:text-amber-600 transition-colors">
              Home
            </Link>
            <Link href="#about" className="text-sm font-medium hover:text-amber-600 transition-colors">
              About
            </Link>
            <Link href="#practice-areas" className="text-sm font-medium hover:text-amber-600 transition-colors">
              Practice Areas
            </Link>
            <Link href="#case-results" className="text-sm font-medium hover:text-amber-600 transition-colors">
              Case Results
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:text-amber-600 transition-colors">
              Testimonials
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-amber-600 transition-colors">
              Contact
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex flex-col items-end">
              <div className="flex items-center gap-1">
                <span className="text-xs bg-green-100 text-green-800 px-1.5 py-0.5 rounded">Online Now</span>
                <Clock className="h-3 w-3 text-green-600" />
              </div>
              <a href="tel:3107951000" className="text-lg font-bold text-amber-600 hover:underline">
                (310) 795-1000
              </a>
            </div>

            <div className="flex gap-2">
              <Button className="bg-amber-600 hover:bg-amber-500 hidden md:flex items-center gap-1">
                <Calendar className="h-4 w-4 mr-1" />
                Free Consultation
              </Button>

              <Button className="bg-amber-700 hover:bg-amber-800 md:hidden">
                <Phone className="h-4 w-4" />
              </Button>

              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden p-2 text-gray-600 hover:text-amber-600"
                aria-label={isMenuOpen ? "Close menu" : "Open menu"}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-lg z-50 border-t">
          <div className="container py-4">
            <nav className="flex flex-col gap-3">
              <Link
                href="#home"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">Home</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
              <Link
                href="#about"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">About</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
              <Link
                href="#practice-areas"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">Practice Areas</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
              <Link
                href="#case-results"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">Case Results</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
              <Link
                href="#testimonials"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">Testimonials</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
              <Link
                href="#contact"
                className="flex items-center justify-between p-2 hover:bg-amber-50 rounded"
                onClick={() => setIsMenuOpen(false)}
              >
                <span className="font-medium">Contact</span>
                <ChevronRight className="h-4 w-4 text-amber-600" />
              </Link>
            </nav>

            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-amber-600" />
                    <span className="text-sm">Call us 24/7</span>
                  </div>
                  <a href="tel:3107951000" className="font-bold text-amber-600">
                    (310) 795-1000
                  </a>
                </div>

                <Button className="w-full bg-amber-600 hover:bg-amber-500">Schedule Free Consultation</Button>

                <div className="bg-amber-50 p-3 rounded-md text-center">
                  <p className="text-sm font-medium text-amber-800">No Fee Unless We Win Your Case</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}

