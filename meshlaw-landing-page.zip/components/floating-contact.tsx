"use client"

import { useState } from "react"
import { Phone, MessageSquare, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"

export function FloatingContact() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="bg-white rounded-lg shadow-xl p-4 mb-4 w-64 border border-amber-200"
            initial={{ opacity: 0, y: 20, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.8 }}
            transition={{ duration: 0.2 }}
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-gray-800">Contact Us</h3>
              <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-700">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-3">
              <a
                href="tel:3107951000"
                className="flex items-center gap-2 p-2 bg-amber-50 rounded-md hover:bg-amber-100 transition-colors"
              >
                <Phone className="h-4 w-4 text-amber-600" />
                <span className="font-medium">(310) 795-1000</span>
              </a>

              <a
                href="#contact"
                className="flex items-center gap-2 p-2 bg-amber-50 rounded-md hover:bg-amber-100 transition-colors"
                onClick={() => setIsOpen(false)}
              >
                <MessageSquare className="h-4 w-4 text-amber-600" />
                <span className="font-medium">Send a Message</span>
              </a>

              <Button
                className="w-full bg-amber-600 hover:bg-amber-500"
                onClick={() => {
                  document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
                  setIsOpen(false)
                }}
              >
                Free Case Evaluation
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        className={`rounded-full shadow-lg flex items-center justify-center ${
          isOpen ? "bg-amber-700 text-white" : "bg-amber-600 text-white"
        }`}
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 400, damping: 17 }}
      >
        <div className="h-14 w-14 flex items-center justify-center">
          {isOpen ? <X className="h-6 w-6" /> : <Phone className="h-6 w-6" />}
        </div>
      </motion.button>
    </div>
  )
}

