import { Star } from "lucide-react"

export function TestimonialSection() {
  return (
    <section className="py-16 bg-amber-50">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Our Clients Say</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our clients have to say about their experience with MeshLaw.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-lg border border-amber-100 relative">
            <div className="absolute -top-4 left-6 bg-amber-600 text-white px-4 py-1 rounded-full text-sm font-medium">
              Car Accident
            </div>
            <div className="flex mb-4 pt-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-amber-500 fill-current" />
              ))}
            </div>
            <p className="text-gray-700 mb-4 italic">
              "After my accident, I was overwhelmed with medical bills and insurance calls. MeshLaw took over everything
              and got me a settlement that was 5x what the insurance company initially offered. They changed my life."
            </p>
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-full bg-gray-200 mr-4">
                <img src="/placeholder.svg?height=48&width=48&text=M" alt="Client" className="h-12 w-12 rounded-full" />
              </div>
              <div>
                <h4 className="font-bold">Michael T.</h4>
                <p className="text-sm text-gray-600">$245,000 Settlement</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-lg border border-amber-100 relative">
            <div className="absolute -top-4 left-6 bg-amber-600 text-white px-4 py-1 rounded-full text-sm font-medium">
              Medical Malpractice
            </div>
            <div className="flex mb-4 pt-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-amber-500 fill-current" />
              ))}
            </div>
            <p className="text-gray-700 mb-4 italic">
              "The hospital denied any wrongdoing after my surgery went wrong. MeshLaw's team of medical experts built
              an ironclad case that resulted in a settlement that covers all my ongoing care needs. I'm forever
              grateful."
            </p>
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-full bg-gray-200 mr-4">
                <img src="/placeholder.svg?height=48&width=48&text=S" alt="Client" className="h-12 w-12 rounded-full" />
              </div>
              <div>
                <h4 className="font-bold">Sarah K.</h4>
                <p className="text-sm text-gray-600">$1.8 Million Recovery</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-lg border border-amber-100 relative">
            <div className="absolute -top-4 left-6 bg-amber-600 text-white px-4 py-1 rounded-full text-sm font-medium">
              Slip and Fall
            </div>
            <div className="flex mb-4 pt-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-amber-500 fill-current" />
              ))}
            </div>
            <p className="text-gray-700 mb-4 italic">
              "I slipped on an unmarked wet floor at a store and suffered a serious back injury. MeshLaw handled
              everything while I focused on recovery. They were compassionate, professional, and got results fast."
            </p>
            <div className="flex items-center">
              <div className="h-12 w-12 rounded-full bg-gray-200 mr-4">
                <img src="/placeholder.svg?height=48&width=48&text=J" alt="Client" className="h-12 w-12 rounded-full" />
              </div>
              <div>
                <h4 className="font-bold">James R.</h4>
                <p className="text-sm text-gray-600">$175,000 Settlement</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <a href="#contact" className="inline-flex items-center text-amber-600 font-bold hover:text-amber-700">
            Read More Client Success Stories
            <svg
              className="ml-2 h-5 w-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}

