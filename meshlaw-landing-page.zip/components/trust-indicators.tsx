export function TrustIndicators() {
  return (
    <section className="py-10 bg-white border-y border-gray-200">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="flex flex-col items-center text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">97%</div>
            <p className="text-gray-700 font-medium">Success Rate</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">$500M+</div>
            <p className="text-gray-700 font-medium">Recovered for Clients</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">25+</div>
            <p className="text-gray-700 font-medium">Years of Experience</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="text-4xl font-bold text-amber-600 mb-2">2,500+</div>
            <p className="text-gray-700 font-medium">Cases Won</p>
          </div>
        </div>
      </div>
    </section>
  )
}

