"use client"

import { useEffect, useMemo, useState } from "react"
import { motion } from "framer-motion"
import { ArrowRight, Phone, CheckCircle, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

function AnimatedHero() {
  const [titleNumber, setTitleNumber] = useState(0)
  const titles = useMemo(() => ["Justice", "Rights", "Life", "Recovery"], [])

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (titleNumber === titles.length - 1) {
        setTitleNumber(0)
      } else {
        setTitleNumber(titleNumber + 1)
      }
    }, 2000)
    return () => clearTimeout(timeoutId)
  }, [titleNumber, titles])

  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-amber-950/90 to-gray-900/75 z-10" />
      <div className="relative h-[700px] w-full">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-PiGRmjU6EaQjrAkDxZyI28bpWbr8e3.png"
          alt="Los Angeles skyline with downtown skyscrapers against snow-capped mountains at sunset"
          className="object-cover h-full w-full"
        />
      </div>
      <div className="container absolute inset-0 z-20 flex items-center justify-between">
        <div className="max-w-xl space-y-6">
          <div className="flex items-center gap-2 bg-amber-600/80 text-white px-3 py-1 rounded-full w-fit text-sm font-medium mb-2">
            <Clock className="h-4 w-4" /> Free Case Review Within 24 Hours
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
            Los Angeles Personal Injury Lawyers Fighting For The{" "}
            <span className="relative inline-block overflow-hidden">
              {titles.map((title, index) => (
                <motion.span
                  key={index}
                  className="absolute font-bold text-amber-500"
                  initial={{ opacity: 0, y: "100%" }}
                  transition={{ type: "spring", stiffness: 50 }}
                  animate={
                    titleNumber === index
                      ? {
                          y: 0,
                          opacity: 1,
                        }
                      : {
                          y: titleNumber > index ? "-100%" : "100%",
                          opacity: 0,
                        }
                  }
                >
                  {title}
                </motion.span>
              ))}
              <span className="invisible">Justice</span>
            </span>{" "}
            You Deserve
          </h1>
          <p className="text-xl text-gray-200">
            MeshLaw has recovered <span className="font-bold text-amber-400">over $500 million</span> for our clients.
            Our experienced attorneys are ready to fight for your maximum compensation.
          </p>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-amber-400 flex-shrink-0" />
              <span className="text-white text-sm">No Fees Unless We Win</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-amber-400 flex-shrink-0" />
              <span className="text-white text-sm">24/7 Legal Support</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-amber-400 flex-shrink-0" />
              <span className="text-white text-sm">97% Success Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-amber-400 flex-shrink-0" />
              <span className="text-white text-sm">Free Case Evaluation</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button
              size="lg"
              className="bg-amber-600 hover:bg-amber-500 text-lg font-bold transition-all transform hover:scale-105"
            >
              Free Case Evaluation <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white bg-amber-700/50 hover:bg-amber-700 transition-all transform hover:scale-105"
            >
              Call Now <Phone className="ml-2 h-4 w-4" />
            </Button>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <div className="flex -space-x-2">
              <img
                src="/placeholder.svg?height=40&width=40&text=Client"
                className="h-8 w-8 rounded-full border-2 border-white"
                alt="Client"
              />
              <img
                src="/placeholder.svg?height=40&width=40&text=Client"
                className="h-8 w-8 rounded-full border-2 border-white"
                alt="Client"
              />
              <img
                src="/placeholder.svg?height=40&width=40&text=Client"
                className="h-8 w-8 rounded-full border-2 border-white"
                alt="Client"
              />
            </div>
            <p className="text-sm text-white">
              <span className="font-bold text-amber-400">500+ clients</span> trusted us this year
            </p>
          </div>
        </div>

        {/* Hero Form */}
        <div className="hidden md:block w-full max-w-md bg-black/40 backdrop-blur-sm p-6 rounded-lg border border-amber-500/20 shadow-xl">
          <div className="bg-amber-600 text-white text-center py-2 px-4 rounded-md -mt-10 mb-4 shadow-lg">
            <h3 className="text-lg font-bold">FREE CASE EVALUATION</h3>
          </div>
          <h3 className="text-xl font-bold mb-2 text-white text-center">Have a case? Tell us more about it</h3>
          <p className="text-white/80 text-sm text-center mb-6">Get a response within 24 hours</p>
          <form className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="hero-name" className="text-sm font-medium text-white">
                Name
              </label>
              <input
                id="hero-name"
                className="w-full px-3 py-2 border border-amber-500/30 bg-white/10 text-white rounded-md placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="hero-email" className="text-sm font-medium text-white">
                Email
              </label>
              <input
                id="hero-email"
                type="email"
                className="w-full px-3 py-2 border border-amber-500/30 bg-white/10 text-white rounded-md placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="john.doe@example.com"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="hero-phone" className="text-sm font-medium text-white">
                Phone
              </label>
              <input
                id="hero-phone"
                type="tel"
                className="w-full px-3 py-2 border border-amber-500/30 bg-white/10 text-white rounded-md placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="(555) 123-4567"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="hero-message" className="text-sm font-medium text-white">
                Tell us about your case
              </label>
              <textarea
                id="hero-message"
                rows={3}
                className="w-full px-3 py-2 border border-amber-500/30 bg-white/10 text-white rounded-md placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="Please provide a brief description of your case..."
              ></textarea>
            </div>
            <Button className="w-full bg-amber-600 hover:bg-amber-500 text-lg py-6 font-bold transition-all transform hover:scale-105">
              Get Your Free Case Review
            </Button>
            <div className="flex items-center justify-center gap-2">
              <div className="flex">
                <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              </div>
              <p className="text-xs text-gray-300">
                <span className="font-bold text-white">4.9/5</span> - 200+ reviews
              </p>
            </div>
            <p className="text-xs text-gray-300 text-center">Your information is 100% confidential and protected</p>
          </form>
        </div>
      </div>
    </div>
  )
}

export { AnimatedHero }

