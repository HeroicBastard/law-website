import { Clock, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"

export function UrgencyBanner() {
  return (
    <section className="bg-amber-600 py-6 text-white">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-white" />
            <div>
              <h3 className="font-bold text-xl">Don't Wait Until It's Too Late</h3>
              <p>Strict deadlines apply to injury claims. Call now for a free consultation.</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Clock className="h-6 w-6 text-white" />
            <p className="font-medium">Statute of limitations may be running</p>
          </div>

          <Button size="lg" className="bg-white text-amber-600 hover:bg-gray-100 font-bold">
            Call (310) 795-1000 Now
          </Button>
        </div>
      </div>
    </section>
  )
}

